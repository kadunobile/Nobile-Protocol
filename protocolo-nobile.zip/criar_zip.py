import os
import zipfile

def zip_dir(zip_name, folder):
    with zipfile.ZipFile(zip_name, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(folder):
            for file in files:
                path = os.path.join(root, file)
                zipf.write(path, os.path.relpath(path, folder))

if __name__ == "__main__":
    zip_dir("protocolo-nobile.zip", ".")
    print("✅ ZIP criado: protocolo-nobile.zip")